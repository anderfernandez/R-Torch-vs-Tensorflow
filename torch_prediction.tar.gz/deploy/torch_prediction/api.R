library(plumber)
library(torch)

#* @apiTitle API de clasificación Torch

#* Predice el tipo de planta
#* @param petal_length Longitud del Petalo 
#* @param petal_width Ancho del Petalo 
#* @param sepal_length Longitud del Sepalo 
#* @param sepal_width Ancho del Sepalo 
#* @post /clasificador
function(petal_length, petal_width, sepal_length, sepal_width) {
    
  labels = c("setosa","versicolor","virginica")
  
  modelo = torch_load("modelo.rt")
  test = c(sepal_length, sepal_width, petal_length, petal_width)
  test = sapply(test, as.numeric)
  test = matrix(test, ncol = 4)

  test = torch_tensor(test, dtype = torch_float())
  pred = modelo(test)
  pred_class =  as.numeric(pred$argmax(dim=2) + 1)
  pred_lab = labels[pred_class]
    
  
  return(pred_lab)
}



